# Bible IA Bot

Un bot Telegram qui envoie un verset biblique par jour, avec option VIP pour des méditations et prières enrichies.

## Commandes disponibles :
- /start
- /verset
- /vip
- /unvip
- /vipstatus

## Déploiement sur Railway
1. Crée un projet Railway
2. Définis les variables d'environnement :
    - `TOKEN` : Token de ton bot Telegram
    - `OPENAI_API_KEY` : Clé API OpenAI
3. Lance le script avec `python main.py`