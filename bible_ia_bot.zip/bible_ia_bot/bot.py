from telegram.ext import ApplicationBuilder, CommandHandler
from handlers.start import start
from handlers.verse import send_daily_verse
from handlers.vip import activate_vip, deactivate_vip, check_vip_status
from database.db import init_db

TOKEN = "TON_TOKEN_TELEGRAM_ICI"

async def start_bot():
    init_db()
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("verset", send_daily_verse))
    app.add_handler(CommandHandler("vip", activate_vip))
    app.add_handler(CommandHandler("unvip", deactivate_vip))
    app.add_handler(CommandHandler("vipstatus", check_vip_status))
    await app.run_polling()