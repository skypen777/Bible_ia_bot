from telegram import Update
from telegram.ext import ContextTypes
from database.db import add_user

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    add_user(user.id, user.username)
    await update.message.reply_text("🙏 Bienvenue ! Tape /verset pour recevoir un verset biblique chaque jour. Tape /vip pour activer le mode VIP.")