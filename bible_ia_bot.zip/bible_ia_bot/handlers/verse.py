from telegram import Update
from telegram.ext import ContextTypes
from openai_api import ask_openai
from database.db import is_user_vip

async def send_daily_verse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if is_user_vip(user_id):
        prompt = "Donne-moi un verset biblique en français avec une méditation chrétienne et une prière pour un chrétien VIP."
    else:
        prompt = "Donne-moi un verset biblique en français avec une courte méditation chrétienne."
    message = ask_openai(prompt)
    await update.message.reply_text(message)