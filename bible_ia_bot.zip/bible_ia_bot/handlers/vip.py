from telegram import Update
from telegram.ext import ContextTypes
from database.db import set_vip_status, is_user_vip

async def activate_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    set_vip_status(user.id, True)
    await update.message.reply_text("🎉 VIP activé avec succès !")

async def deactivate_vip(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    set_vip_status(user.id, False)
    await update.message.reply_text("🚫 VIP désactivé.")

async def check_vip_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    vip = is_user_vip(user.id)
    if vip:
        await update.message.reply_text("✅ Tu es VIP.")
    else:
        await update.message.reply_text("❌ Tu n'es pas VIP.")